# Edit this file to change settings
CONFIG = {
    'beginDate': '2019-02-25',
    # The beginDate of the term in %Y-%m-%d
    # Should be a Monday

    # 'userName': 'yourUsername',
    # 'passWord': 'yourPassword',

    'default': True
    # 'default' sets whether you want to use the newest classTable or not
    # if default is False, you need to select which term will you use
}
